from ast import keyword
import pandas as pd
import matplotlib.pyplot as plt
from setuptools import sic
plt.style.use('fivethirtyeight')
import seaborn as sns
import numpy as np
import json
import warnings
warnings.filterwarnings('ignore')
import base64
import io
# from scipy.misc import imread
import codecs
import operator
from scipy import spatial
import csv
from csv import writer
import requests
# from IPython.display import HTML

#source: https://www.kaggle.com/code/ash316/what-s-my-score
#Based on the above link. This application dynamically adds and cleans searched movies to the csv files tmdb_5000_movies and tmdb_5000_credits
#implemented method to add given movie without running entire model

#return a binary interpetation of what genre it has
def binaryGenre(genre_list, genreList):
    binaryList = []
    for genre in genreList:
        if genre in genre_list:
            binaryList.append(1)
        else:
            binaryList.append(0)
    return binaryList

def binaryCast(cast_list, castList):
    binaryList = []
    for genre in castList:
        if genre in cast_list:
            binaryList.append(1)
        else:
            binaryList.append(0)
    return binaryList

def binaryDirector(director_list, directorList):
    binaryList = []
    for direct in directorList:
        if direct in director_list:
            binaryList.append(1)
        else:
            binaryList.append(0)
    return binaryList

def binaryKeyword(words, words_list):
    binaryList = []
    for genre in words_list:
        if genre in words:
            binaryList.append(1)
        else:
            binaryList.append(0)
    return binaryList

def director(x):
    for i in x:
        if i['job'] == 'Director':
            return i['name']

def xstr(s):
    if s is None:
        return ''
    return str(s)

#finding similarity using cosine similarity
def Similarity(movieId1, movieId2, movies):
    a = movies.loc[movies['id'] == movieId1]
    b = movies.loc[movies['id'] == movieId2]
    
    genresA = a['genres_bin'].tolist()
    genresB = b['genres_bin'].tolist()
    
    genreDistance = spatial.distance.cosine(genresA, genresB)
    
    scoreA = a['cast_bin'].tolist()
    scoreB = b['cast_bin'].tolist()
    scoreDistance = spatial.distance.cosine(scoreA, scoreB)
    
    directA = a['director_bin'].tolist()
    directB = b['director_bin'].tolist()
    directDistance = spatial.distance.cosine(directA, directB)
    
    wordsA = a['words_bin'].tolist()
    wordsB = b['words_bin'].tolist()
    wordsDistance = spatial.distance.cosine(wordsA, wordsB)

    if(int(movieId2) == 41733):
        print(wordsA)
        print(genreDistance)
        print(directDistance)
        print(scoreDistance)
        print(wordsDistance)

    return genreDistance + directDistance + scoreDistance + wordsDistance

def getNeighbors(baseMovie, K, movies):
    distances = []
    for index, movie in movies.iterrows():
        if movie['id'] != baseMovie['id'].values[0]:
            dist = Similarity(baseMovie['id'].values[0], movie['id'], movies)
            distances.append((movie['id'], dist))
            
    distances.sort(key=operator.itemgetter(1))
    neighbors = []
    for x in range(K):
        neighbors.append(distances[x])
    print(neighbors)
    return neighbors

def add_and_clean(json_movie, json_credits, json_keywords, genreList, directorList, castList, words_list):

    #adds data of new movie to the existing csv file
    #if the movie already exists in the csv it does not add it
    movies=pd.read_csv('./data/tmdb_5000_movies.csv')

    not_in = True
    for cur_movie_id in movies.id:
        if cur_movie_id == json_movie["id"]:
            not_in = False
    if not_in:
        data_movies = json.dumps(json_movie["budget"]) + '|' + json.dumps(json_movie["genres"]) + '|' + '|' + json.dumps(json_movie["id"]) + '|' + json.dumps(json_keywords["keywords"])\
            + '|' + json.dumps(json_movie["original_language"]) + '|' + json.dumps(json_movie["original_title"]) + '|' + '|' + json.dumps(json_movie["popularity"]) + '|' + \
            json.dumps(json_movie["production_companies"]) + '|' + json.dumps(json_movie["production_countries"]) + '|' + str(json_movie["release_date"]) + '|' + \
            json.dumps(json_movie["revenue"]) + '|' + json.dumps(json_movie["runtime"]) + '|' + json.dumps(json_movie["spoken_languages"]) + '|' + '|' + '|' + json.dumps(json_movie["title"]) \
            + '|' + json.dumps(json_movie["vote_average"]) + '|' + json.dumps(json_movie["vote_count"])
        data_credits = json.dumps(json_credits["id"]) + '|' + json.dumps(json_movie["original_title"]) + '|' + json.dumps(json_credits["cast"]) + '|' + json.dumps(json_credits["crew"])
        with open('./data/tmdb_5000_movies.csv', 'a+', newline='') as movies_obj:
            # Create a writer object from csv module
            csv_writer = writer(movies_obj)
            # Add contents of list as last row in the csv file
            csv_writer.writerow(data_movies.split('|'))
        with open('./data/tmdb_5000_credits.csv', 'a+', newline='') as credits_obj:
            # Create a writer object from csv module
            csv_writer = writer(credits_obj)
            # Add contents of list as last row in the csv file
            csv_writer.writerow(data_credits.split('|'))

    movies=pd.read_csv('./data/tmdb_5000_movies.csv')
    mov=pd.read_csv('./data/tmdb_5000_credits.csv')

    # changing the genres column from json to string
    movies['genres']=movies['genres'].apply(json.loads)
    for index,i in zip(movies.index,movies['genres']):
        list1=[]
        for j in range(len(i)):
            list1.append((i[j]['name']))# the key 'name' contains the name of the genre
        movies.loc[index,'genres']=str(list1)
        
    # changing the keywords column from json to string
    movies['keywords']=movies['keywords'].apply(json.loads)
    for index,i in zip(movies.index,movies['keywords']):
        list1=[]
        for j in range(len(i)):
            list1.append((i[j]['name']))
        movies.loc[index,'keywords']=str(list1)
        
    ## changing the production_companies column from json to string
    movies['production_companies']=movies['production_companies'].apply(json.loads)
    for index,i in zip(movies.index,movies['production_companies']):
        list1=[]
        for j in range(len(i)):
            list1.append((i[j]['name']))
        movies.loc[index,'production_companies']=str(list1)
        
    # changing the production_countries column from json to string    
    movies['production_countries']=movies['production_countries'].apply(json.loads)
    for index,i in zip(movies.index,movies['production_countries']):
        list1=[]
        for j in range(len(i)):
            list1.append((i[j]['name']))
        movies.loc[index,'production_countries']=str(list1)
        
    # changing the cast column from json to string
    mov['cast']=mov['cast'].apply(json.loads)
    for index,i in zip(mov.index,mov['cast']):
        list1=[]
        for j in range(len(i)):
            list1.append((i[j]['name']))
        mov.loc[index,'cast']=str(list1)

    # changing the crew column from json to string    
    mov['crew']=mov['crew'].apply(json.loads)
    mov['crew']=mov['crew'].apply(director)
    mov.rename(columns={'crew':'director'},inplace=True)

    movies=movies.merge(mov,left_on='id',right_on='movie_id',how='left')# merging the two csv files
    movies=movies[['id','original_title','genres','cast','vote_average','director','keywords']]

    movies['genres']=movies['genres'].str.strip('[]').str.replace(' ','').str.replace("'",'')
    movies['genres']=movies['genres'].str.split(',')

    #sort genres
    for i,j in zip(movies['genres'],movies.index):
        list2=[]
        list2=i
        list2.sort()
        movies.loc[j,'genres']=str(list2)
    movies['genres']=movies['genres'].str.strip('[]').str.replace(' ','').str.replace("'",'')
    movies['genres']=movies['genres'].str.split(',')

    #find all genres
    for index, row in movies.iterrows():
        genres = row["genres"]
        for genre in genres:
            if genre not in genreList:
                genreList.append(genre)
    genreList[:10]

    movies['genres_bin'] = movies['genres'].apply(lambda x: binaryGenre(x, genreList))

    movies['cast']=movies['cast'].str.strip('[]').str.replace(' ','').str.replace("'",'').str.replace('"','')
    movies['cast']=movies['cast'].str.split(',')

    #keep 4 most important actors for each movie sorted
    for i,j in zip(movies['cast'],movies.index):
        list2=[]
        list2=i[:4]
        movies.loc[j,'cast']=str(list2)
    movies['cast']=movies['cast'].str.strip('[]').str.replace(' ','').str.replace("'",'')
    movies['cast']=movies['cast'].str.split(',')
    for i,j in zip(movies['cast'],movies.index):
        list2=[]
        list2=i
        list2.sort()
        movies.loc[j,'cast']=str(list2)
    movies['cast']=movies['cast'].str.strip('[]').str.replace(' ','').str.replace("'",'')
    movies['cast']=movies['cast'].str.split(',')

    #keep track of every actor (taken from every movies top 4)
    for index, row in movies.iterrows():
        cast = row["cast"]
        for i in cast:
            if i not in castList:
                castList.append(i)

    #binary conversion for actors
    movies['cast_bin'] = movies['cast'].apply(lambda x: binaryCast(x, castList))

    #clean directors and add binary
    movies['director']=movies['director'].apply(xstr)

    for i in movies['director']:
        if i not in directorList:
            directorList.append(i)

    movies['director_bin'] = movies['director'].apply(lambda x: binaryDirector(x, directorList))

    #clean keywords
    movies['keywords']=movies['keywords'].str.strip('[]').str.replace(' ','').str.replace("'",'').str.replace('"','')
    movies['keywords']=movies['keywords'].str.split(',')
    for i,j in zip(movies['keywords'],movies.index):
        list2=[]
        list2=i
        movies.loc[j,'keywords']=str(list2)
    movies['keywords']=movies['keywords'].str.strip('[]').str.replace(' ','').str.replace("'",'')
    movies['keywords']=movies['keywords'].str.split(',')
    for i,j in zip(movies['keywords'],movies.index):
        list2=[]
        list2=i
        list2.sort()
        movies.loc[j,'keywords']=str(list2)
    movies['keywords']=movies['keywords'].str.strip('[]').str.replace(' ','').str.replace("'",'')
    movies['keywords']=movies['keywords'].str.split(',')
    #keyword list
    for index, row in movies.iterrows():
        genres = row["keywords"]
        for genre in genres:
            if genre not in words_list:
                words_list.append(genre)

    #binary conversion of keywords, remove movies with score 0 and no director
    movies['words_bin'] = movies['keywords'].apply(lambda x: binaryKeyword(x, words_list))
    movies=movies[(movies['vote_average']!=0)]
    movies=movies[movies['director']!='']

    # new_id=list(range(0,movies.shape[0]))
    # movies['new_id']=new_id
    # movies=movies[['original_title','genres','vote_average','genres_bin','cast_bin','new_id','director','director_bin','words_bin']]
    movies=movies[['original_title','genres','vote_average','genres_bin','cast_bin','id','director','director_bin','words_bin']]
    print(len(genreList))
    print(len(castList))
    print(len(directorList))
    print(len(words_list))
    return movies


#score predictor
def whats_my_score(name, movies):
    new_movie=movies[movies['original_title'].str.contains(name)].iloc[0].to_frame().T

    print('Selected Movie: ',new_movie.original_title.values[0])

    K = 10
    avgRating = 0
    neighbors = getNeighbors(new_movie, K, movies)
    allSimilar = ''
    
    for neighbor in neighbors:
        neighborMovie = movies.loc[movies['id'] == neighbor[0]]
        avgRating = avgRating + neighborMovie['vote_average'].values[0]
        allSimilar += neighborMovie['original_title'].values[0]+" | Genres: "+str(neighborMovie['genres'].values[0]).strip('[]').replace(' ','')+" | Rating: "+str(neighborMovie['vote_average'].values[0]) + '\n'
        # print(neighborMovie['original_title'].values[0]+" | Genres: "+str(neighborMovie['genres']).strip('[]').replace(' ','')+" | Rating: "+str(neighborMovie['vote_average'].values[0])+'\n')
    avgRating = avgRating/K
    print('The predicted rating for %s is: %f' %(new_movie['original_title'].values[0],avgRating))
    print('The actual rating for %s is %f' %(new_movie['original_title'].values[0],new_movie['vote_average'].values[0]))
    return (allSimilar, avgRating)

def add_to_database(movie_to_search):
    api_key = 'api_key=27989ba887194f26874a5e95813460ab'
    api_search = 'https://api.themoviedb.org/3/search/movie?'
    api_movie = 'https://api.themoviedb.org/3/movie/'
    search_url = api_search + api_key + "&language=en-US&query=" + movie_to_search+ "&page=1&include_adult=false"
    search_response = requests.get(search_url)

    movie_id = search_response.json()["results"][0]["id"]
    movie_url = api_movie + str(movie_id) + "?" + api_key + "&language=en-US"
    credit_url = api_movie + str(movie_id) + "/credits?" + api_key + "&language=en-US"
    movie_response = requests.get(movie_url)
    credit_response = requests.get(credit_url)
    keywords_url = api_movie + str(movie_id) + "/keywords?" + api_key + "&language=en-US"
    keywords_response = requests.get(keywords_url)

    movies=pd.read_csv('./data/tmdb_5000_movies.csv')

    json_movie = movie_response.json()
    json_credits = credit_response.json()
    json_keywords = keywords_response.json()

    not_in = True
    for cur_movie_id in movies.id:
        if cur_movie_id == json_movie["id"]:
            not_in = False
            print("Did not add: " + json.dumps(json_movie["original_title"]))
    if not_in:
        data_movies = json.dumps(json_movie["budget"]) + '|' + json.dumps(json_movie["genres"]) + '|' + '|' + json.dumps(json_movie["id"]) + '|' + json.dumps(json_keywords["keywords"])\
            + '|' + json.dumps(json_movie["original_language"]) + '|' + json.dumps(json_movie["original_title"]) + '|' + '|' + json.dumps(json_movie["popularity"]) + '|' + \
            json.dumps(json_movie["production_companies"]) + '|' + json.dumps(json_movie["production_countries"]) + '|' + str(json_movie["release_date"]) + '|' + \
            json.dumps(json_movie["revenue"]) + '|' + json.dumps(json_movie["runtime"]) + '|' + json.dumps(json_movie["spoken_languages"]) + '|' + '|' + '|' + json.dumps(json_movie["title"]) \
            + '|' + json.dumps(json_movie["vote_average"]) + '|' + json.dumps(json_movie["vote_count"])
        data_credits = json.dumps(json_credits["id"]) + '|' + json.dumps(json_movie["original_title"]) + '|' + json.dumps(json_credits["cast"]) + '|' + json.dumps(json_credits["crew"])
        with open('./data/tmdb_5000_movies.csv', 'a+', newline='') as movies_obj:
            # Create a writer object from csv module
            csv_writer = writer(movies_obj)
            # Add contents of list as last row in the csv file
            csv_writer.writerow(data_movies.split('|'))
        with open('./data/tmdb_5000_credits.csv', 'a+', newline='') as credits_obj:
            # Create a writer object from csv module
            csv_writer = writer(credits_obj)
            # Add contents of list as last row in the csv file
            csv_writer.writerow(data_credits.split('|'))
        print("Added: " + json.dumps(json_movie["original_title"]))

def run(movie_to_search):

    api_key = 'api_key=27989ba887194f26874a5e95813460ab'
    api_search = 'https://api.themoviedb.org/3/search/movie?'
    api_movie = 'https://api.themoviedb.org/3/movie/'
    search_url = api_search + api_key + "&language=en-US&query=" + movie_to_search+ "&page=1&include_adult=false"
    search_response = requests.get(search_url)

    movie_id = search_response.json()["results"][0]["id"]
    movie_url = api_movie + str(movie_id) + "?" + api_key + "&language=en-US"
    credit_url = api_movie + str(movie_id) + "/credits?" + api_key + "&language=en-US"
    movie_response = requests.get(movie_url)
    credit_response = requests.get(credit_url)
    keywords_url = api_movie + str(movie_id) + "/keywords?" + api_key + "&language=en-US"
    keywords_response = requests.get(keywords_url)

    movie_name = movie_response.json()["original_title"]

    genreList = []
    castList = []
    directorList = []
    words_list = []

    movies = add_and_clean(movie_response.json(), credit_response.json(), keywords_response.json(), genreList, castList, directorList, words_list)
    res_similar, res_rating = whats_my_score(movie_name, movies)
    print(res_similar)

# add_to_database("joker")
run("joker")